Google App Engine + zc.buildout + Google Glass
===

## Installation
    $ python bootstrap.py
    $ ./bin/buildout

## Configuration
Open `config.py` and set `appname`, `client_id`, and `client_secret` to match your [Google APIs console](https://code.google.com/apis/console/) setup

## Running the example
Launch the appserver

    $ ./bin/dev_appserver

Point your web browser to [http://localhost:8765/](http://localhost:8765/)

- Enjoy

