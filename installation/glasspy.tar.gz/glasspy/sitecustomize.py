import sys
sys.setdefaultencoding('latin-1')